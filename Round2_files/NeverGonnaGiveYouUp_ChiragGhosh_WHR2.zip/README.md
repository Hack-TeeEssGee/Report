Production frontend URL : kgpverse.chiragghosh.me

Production Backend URL: api.kgpverse.chiragghosh.me



Official accounts cannot be made by anyone. So we have made a test tsg official account for the judges to use for testing.

﻿Test TSG official account :

email: test@gmail.com
password: yo!kgp

